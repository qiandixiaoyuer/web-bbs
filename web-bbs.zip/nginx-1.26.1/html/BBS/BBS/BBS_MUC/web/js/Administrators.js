
new Vue({
    el: "#Administrators",
    data: {
        users:[],
        queryId: '',
        // buttonClicked:false
    },
    methods: {
        adminQuery: function() {
            this.queryId = document.getElementById("queryAdminIdText").value;
            axios.get("http://localhost:9090/users").then(result => {
                // console.log(result.data);
                this.users = result.data.data.rows;
                // console.log(result.data.data.rows)；              
            });
            // alert("查询成功!");
        }
       
    }
});


new Vue({
    el: "#UserMsg",
    data: {
        users:[],
        queryId: '',
    },
    methods: {
        userQuery: function() {
            this.queryId = document.getElementById("queryUserIdText").value;
            axios.get("http://localhost:9090/users").then(result => {
                this.users = result.data.data.rows;
            })
        }
    }
});

new Vue({
    el: "#post",
    data: {
        posts:[],
        queryId: '',
    },
    methods: {
        postQuery: function() {
            this.queryId = document.getElementById("queryPostIdText").value;
            axios.get("http://localhost:9090/posts").then(result => {
                this.posts = result.data.data.rows;
            })
        }
    }
});


const comment = new Vue({
    el: "#comment",
    data: {
        comments:[],
        postId: '', // 确保 postId 在 data 中定义
    },
    methods: {
        commentQuery: function() {
            axios.get(`http://localhost:9090/replies/${this.postId}`)
            .then(result => {
                this.comments = result.data.data.rows;
            })
            .catch(error => {
                console.error("发生错误：", error);
                // 这里可以添加向用户显示错误信息的逻辑
            });
        }
    }
})
