// main.js
Vue.prototype.baseUrl = "https://www.example.com/api"
